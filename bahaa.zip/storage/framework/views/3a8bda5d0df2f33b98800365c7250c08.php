<?php $__env->startSection('title', 'الصفحة الرئيسية'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Success and Error Messages -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>




    <div class="container-fluid py-4">
        <div class="container text-center">
            <div class="d-flex flex-wrap justify-content-center">
                <?php $__currentLoopData = [['title' => 'Slide', 'imgId' => 1], ['title' => 'Gallery', 'imgId' => 2], ['title' => 'Our Group', 'imgId' => 3], ['title' => 'Why Bahaa?', 'imgId' => 4], ['title' => 'video', 'imgId' => 5], ['title' => 'Customer opinions', 'imgId' => 6], ['title' => 'blog', 'imgId' => 7], ['title' => 'services', 'imgId' => 8]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mx-2 mb-4" style="width: 18rem;">
                        <div class="card-header">
                            <h5 class="card-title"><?php echo e($card['title']); ?></h5>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('slides.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <!-- Display the image thumbnail -->
                                <img src="../../bahaa/public/assets/img/download.jpg" class="card-img-top" alt="..."
                                id="uploadImage<?php echo e($card['imgId']); ?>" style="max-height: 200px;">




                                <!-- Comments Input -->
                                <div class="form-floating mb-3">
                                    <textarea class="form-control" id="floatingTextarea<?php echo e($card['imgId']); ?>" name="text"></textarea>
                                    <label for="floatingTextarea<?php echo e($card['imgId']); ?>">Comments</label>
                                </div>

                                <!-- Action Buttons -->
                                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-upload"></i></button>

                                <a href="<?php echo e(route('slides.index', ['id' => $card['imgId']])); ?>" class="btn btn-primary"><i
                                        class="fa-solid fa-eye"></i></a>


                                <a href="<?php echo e(route('slides.trash', ['id' => $card['imgId']])); ?>" class="btn btn-danger">
                                    <i class="fa-solid fa-trash"></i>
                                </a>


                                <!-- Hidden file input and type -->
                                <input type="file" id="fileInput<?php echo e($card['imgId']); ?>" name="img"
                                    style="display: none;">
                                <input type="hidden" id="type" value="<?php echo e($card['imgId']); ?>" name="type">
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>



    <script>
        $(document).ready(function() {
            const cardIds = [1, 2, 3, 4, 5, 6, 7, 8];

            // Handle image preview on click
            cardIds.forEach(id => {
                $(`#uploadImage${id}`).click(function() {
                    $(`#fileInput${id}`).click();
                });

                // Preview the selected image
                $(`#fileInput${id}`).change(function(event) {
                    const file = event.target.files[0];
                    if (file) {
                        const reader = new FileReader();

                        reader.onload = function(e) {
                            $(`#uploadImage${id}`).attr('src', e.target.result);
                        };

                        reader.readAsDataURL(file);
                    }
                });
            });
        });
    </script>

    <!-- Custom styles -->
    <style>
        .card-img-top {
            cursor: pointer;
        }

        .card-title {
            font-weight: bold;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bahaa\resources\views/dashboard/index.blade.php ENDPATH**/ ?>