<?php $__env->startSection('title', 'الصفحة الرئيسية'); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid py-4">
    <div class="container text-center">
        <div class="row">
            <!-- Card 1 -->
            <div class="col">
                <div class="card" style="width: 18rem;">
                    <div class="card-header">
                        <div>
                            <i class="fa-solid fa-trash"></i>
                        </div>
                    </div>
                    <div class="card-body">
                        <img src="../assets/img/download.jpg" class="card-img-top" alt="..." id="uploadImage1">
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea1"></textarea>
                            <label for="floatingTextarea1">Comments</label>
                        </div>
                        <br>
                        <button class="btn btn-primary">update</button>
                        <input type="file" id="fileInput1" style="display: none;">
                    </div>
                </div>
            </div>


    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\high_level\bahaa\resources\views/dashboard/tables.blade.php ENDPATH**/ ?>