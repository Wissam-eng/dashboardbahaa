<?php $__env->startSection('title', 'الصفحة الرئيسية'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .alert {
            text-align: center;
            font-weight: bold;
        }

        .img-container {
            cursor: pointer;
            border: 1px solid #ddd;
            padding: 5px;
            border-radius: 5px;
        }

        .img-container:hover {
            border-color: #007bff;
        }

        input[type="file"] {
            display: none;
        }
    </style>

    <?php if($id == 1): ?>
        <div class="alert alert-primary" role="alert">
            Slide
        </div>
    <?php elseif($id == 2): ?>
        <div class="alert alert-secondary" role="alert">
            Gallery
        </div>
    <?php elseif($id == 3): ?>
        <div class="alert alert-success" role="alert">
            Our Group
        </div>
    <?php elseif($id == 4): ?>
        <div class="alert alert-danger" role="alert">
            Why Bahaa?
        </div>
    <?php elseif($id == 5): ?>
        <div class="alert alert-warning" role="alert">
            Blog
        </div>
    <?php elseif($id == 6): ?>
        <div class="alert alert-info" role="alert">
            Services
        </div>
    <?php elseif($id == 7): ?>
        <div class="alert alert-info" role="alert">
            Video
        </div>
    <?php elseif($id == 8): ?>
        <div class="alert alert-info" role="alert">
            Views
        </div>
    <?php endif; ?>









    <?php dd($type_page); ?>





    <div class="container-fluid py-4">
        <div class="container text-center">
            <div class="d-flex justify-content-center flex-wrap">
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mx-2 mb-3" style="width: 18rem;">
                        <div class="card-header">
                            <?php if($type_page == 'untrashed'): ?>

                            <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo e($slid->id); ?>)">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                            <?php elseif($type_page == 'trash'): ?>
                            <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo e($slid->id); ?>)">
                                <i class="fa-solid fa-arrow-rotate-left"></i>                            </button>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('dashboard.slides.update', $slid->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="img-container"
                                    onclick="document.getElementById('fileInput<?php echo e($slid->id); ?>').click();">
                                    <img src="<?php echo e(asset('storage/' . $slid->img)); ?>" class="card-img-top" alt="..."
                                        id="uploadImage<?php echo e($slid->id); ?>">
                                </div>

                                <div class="form-floating mt-3">
                                    <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea<?php echo e($slid->id); ?>"
                                        name="text"><?php echo e($slid->text); ?></textarea>
                                    <label for="floatingTextarea<?php echo e($slid->id); ?>">Text</label>
                                </div>

                                <br>

                                <input type="file" id="fileInput<?php echo e($slid->id); ?>" name="img"
                                    onchange="previewImage(event, <?php echo e($slid->id); ?>)">

                                <button class="btn btn-primary mt-2">Update</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function confirmDelete(slideId) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    deleteSlide(slideId);
                }
            });
        }

        function deleteSlide(slideId) {
            var form = $('<form>', {
                method: 'POST',
                action: '/dashboard/slides/' + slideId
            });

            form.append($('<input>', {
                type: 'hidden',
                name: '_token',
                value: "<?php echo e(csrf_token()); ?>"
            }));

            form.append($('<input>', {
                type: 'hidden',
                name: '_method',
                value: 'DELETE'
            }));

            $('body').append(form);
            form.submit();
        }

        function previewImage(event, id) {
            var reader = new FileReader();
            reader.onload = function() {
                $('#uploadImage' + id).attr('src', reader.result);
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\high_level\bahaa\resources\views/dashboard/our_gorp.blade.php ENDPATH**/ ?>