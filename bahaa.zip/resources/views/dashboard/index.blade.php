@extends('layouts.app')

@section('title', 'الصفحة الرئيسية')

@section('content')

    <!-- Success and Error Messages -->
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif




    <div class="container-fluid py-4">
        <div class="container text-center">
            <div class="d-flex flex-wrap justify-content-center">
                @foreach ([['title' => 'Slide', 'imgId' => 1], ['title' => 'Gallery', 'imgId' => 2], ['title' => 'Our Group', 'imgId' => 3], ['title' => 'Why Bahaa?', 'imgId' => 4], ['title' => 'video', 'imgId' => 5], ['title' => 'Customer opinions', 'imgId' => 6], ['title' => 'blog', 'imgId' => 7], ['title' => 'services', 'imgId' => 8]] as $card)
                    <div class="card mx-2 mb-4" style="width: 18rem;">
                        <div class="card-header">
                            <h5 class="card-title">{{ $card['title'] }}</h5>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('slides.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf

                                <!-- Display the image thumbnail -->
                                <img src="../../bahaa/public/assets/img/download.jpg" class="card-img-top" alt="..."
                                id="uploadImage{{ $card['imgId'] }}" style="max-height: 200px;">




                                <!-- Comments Input -->
                                <div class="form-floating mb-3">
                                    <textarea class="form-control" id="floatingTextarea{{ $card['imgId'] }}" name="text"></textarea>
                                    <label for="floatingTextarea{{ $card['imgId'] }}">Comments</label>
                                </div>

                                <!-- Action Buttons -->
                                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-upload"></i></button>

                                <a href="{{ route('slides.index', ['id' => $card['imgId']]) }}" class="btn btn-primary"><i
                                        class="fa-solid fa-eye"></i></a>


                                <a href="{{ route('slides.trash', ['id' => $card['imgId']]) }}" class="btn btn-danger">
                                    <i class="fa-solid fa-trash"></i>
                                </a>


                                <!-- Hidden file input and type -->
                                <input type="file" id="fileInput{{ $card['imgId'] }}" name="img"
                                    style="display: none;">
                                <input type="hidden" id="type" value="{{ $card['imgId'] }}" name="type">
                            </form>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>



    <script>
        $(document).ready(function() {
            const cardIds = [1, 2, 3, 4, 5, 6, 7, 8];

            // Handle image preview on click
            cardIds.forEach(id => {
                $(`#uploadImage${id}`).click(function() {
                    $(`#fileInput${id}`).click();
                });

                // Preview the selected image
                $(`#fileInput${id}`).change(function(event) {
                    const file = event.target.files[0];
                    if (file) {
                        const reader = new FileReader();

                        reader.onload = function(e) {
                            $(`#uploadImage${id}`).attr('src', e.target.result);
                        };

                        reader.readAsDataURL(file);
                    }
                });
            });
        });
    </script>

    <!-- Custom styles -->
    <style>
        .card-img-top {
            cursor: pointer;
        }

        .card-title {
            font-weight: bold;
        }
    </style>

@endsection
